exports.home = (req, res) => {
  res.send('Bem-vindo ao projeto Scrum!');
};

exports.status = (req, res) => {
  res.json({ status: 'Funcionalidade principal em desenvolvimento' });
};
