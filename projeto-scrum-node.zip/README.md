# projeto-scrum-node
Aplicação Node.js com estrutura básica para o desenvolvimento das funcionalidades principais.