// dados.js

// Simulação da coleção "usuarios"
const usuarios = [
  {
    id: 1,
    nome: "Maria Silva",
    email: "maria@email.com"
  }
];

// Simulação da coleção "navegacao"
const navegacoes = [
  {
    usuarioId: 1,
    pagina: "tela_de_login",
    acao: "clique_no_botao_login",
    timestamp: "2025-05-15T10:15:00Z"
  }
];

// Exportar os dados
module.exports = { usuarios, navegacoes };
