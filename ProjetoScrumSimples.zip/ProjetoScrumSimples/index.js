// index.js
const express = require("express");
const app = express();
const port = 3000;

// Importa os dados simulados
const { usuarios, navegacoes } = require("./dados");

app.get("/", (req, res) => {
  res.send("Projeto Scrum 27 - Prototipo Simples");
});

// Lista os usuários
app.get("/usuarios", (req, res) => {
  res.json(usuarios);
});

// Lista navegações
app.get("/navegacoes", (req, res) => {
  res.json(navegacoes);
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
